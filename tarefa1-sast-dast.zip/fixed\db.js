// mesmo mock do outro, mas agora com query(text, params) tipo o driver
// do pg de verdade, os parametros nunca entram na string
const bcrypt = require('bcryptjs');

const users = [
  { id: 1, email: 'admin@gofood.com', password_hash: bcrypt.hashSync('admin123', 10), role: 'admin' },
  { id: 2, email: 'joao@gofood.com', password_hash: bcrypt.hashSync('senha123', 10), role: 'customer' },
];

const products = [
  { id: 1, name: 'Feijoada', price: 19.9 },
  { id: 2, name: 'Suco de Acerola', price: 8.5 },
];

let orders = [
  { id: 1, user_id: 2, items: '[{"productId":1,"qty":2}]', total: 39.8, address: 'Rua A, 123' },
];

let refreshTokens = []; // { userId, tokenHash, revoked, expiresAt }

function query(text, params = []) {
  if (text.includes('SELECT id, email, password_hash, role FROM users WHERE email')) {
    const [email] = params;
    return { rows: users.filter(u => u.email === email) };
  }
  if (text.includes('SELECT id, role FROM users WHERE id')) {
    const [id] = params;
    return { rows: users.filter(u => u.id === id).map(u => ({ id: u.id, role: u.role })) };
  }
  if (text.includes('INSERT INTO refresh_tokens')) {
    const [userId, tokenHash] = params;
    refreshTokens.push({ userId, tokenHash, revoked: false, expiresAt: Date.now() + 7 * 24 * 3600 * 1000 });
    return { rows: [] };
  }
  if (text.includes('FROM refresh_tokens WHERE user_id')) {
    const [userId, tokenHash] = params;
    const valid = refreshTokens.filter(t => t.userId === userId && t.tokenHash === tokenHash && !t.revoked && t.expiresAt > Date.now());
    return { rows: valid.map((_, i) => ({ id: i })) };
  }
  if (text.includes('SELECT * FROM orders WHERE id')) {
    const [id] = params;
    return { rows: orders.filter(o => o.id === id) };
  }
  if (text.includes('SELECT id, price FROM products WHERE id = ANY')) {
    const [ids] = params;
    return { rows: products.filter(p => ids.includes(p.id)) };
  }
  if (text.startsWith('INSERT INTO orders')) {
    const [userId, itemsJson, total, address] = params;
    const id = orders.length + 1;
    orders.push({ id, user_id: userId, items: itemsJson, total, address });
    return { rows: [{ id }] };
  }
  if (text.includes('SELECT * FROM orders ORDER BY')) {
    return { rows: orders };
  }
  return { rows: [] };
}

module.exports = { query, users, products, orders };
